#error "This header with legacy C API declarations has been removed from OpenCV. Legacy contants are available from legacy/constants_c.h file."
